
package tiendadearreglos_p2;
//ERDADEROOOOOOOOOOOOOOOOOO
//ERDADEROOOOOOOOOOOOOOOOOO
//ERDADEROOOOOOOOOOOOOOOOOO
//ERDADEROOOOOOOOOOOOOOOOOO
//ERDADEROOOOOOOOOOOOOOOOOO
public class TiendaDeArreglos_P2 {


    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
