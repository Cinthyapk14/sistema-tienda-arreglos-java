
package modelo.DAO;

import java.io.File;
import modelo.DTO.Venta;
import java.util.ArrayList;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import java.io.IOException;

public class VentaDAO {
    
    String ruta = "src/archivos/ventas.obj";//ruta relativaa del archivo con datos de la venta
    
    public String escribir (ArrayList<Venta> listaVentas){
        String mensaje;
        try(FileOutputStream fos = new FileOutputStream(ruta);
                ObjectOutputStream oos = new ObjectOutputStream(fos);//este objeto nos permite hacer la serializacion 
            ){
            oos.writeObject(listaVentas);
            mensaje = "Venta guardado exitosamente";
        }catch(IOException io){
            System.out.println("Error al escribir la venta" + io.getMessage());
            mensaje = "No se guardó correctamente";
        }
        return mensaje;
    }
    
    
    public ArrayList<Venta> leer(){
        ArrayList<Venta> listaVenta = new ArrayList<>();
        
        //Verificar si el archivo existe
        File file = new File(ruta);
        if(!file.exists()){
            return listaVenta; //retorna la lista vacia
        }
        
        try(FileInputStream fis = new FileInputStream(ruta);
              ObjectInputStream ois = new ObjectInputStream(fis);
        ){
            listaVenta = (ArrayList<Venta>)ois.readObject();
        }catch(IOException ioe){
            System.out.println("Error en leer venta " + ioe.getMessage());
        }catch(ClassNotFoundException cnf){
            System.out.println("Error en leer venta (class not found)" + cnf.getMessage());
        }
        return listaVenta;
        
    }
    
    //metodo para el manejo de dato
    public String guardar(Venta venta){
        ArrayList<Venta> listaVenta = leer();//leer las ventas existentes
        
        
        //Verificar si la venta existe
        for(Venta ventaRealizada:listaVenta){
            if(ventaRealizada.getNumeroFactura() == venta.getNumeroFactura()){
                return "Ya existe venta ese número de factura " + venta.getNumeroFactura();
            }
        }
        
        listaVenta.add(venta);
        String mensaje = escribir(listaVenta);
        return mensaje;
    }
    
    public String eliminar(int numeroFactura){
        ArrayList<Venta> listaVenta = leer();
        boolean encontrado = false;
        for(int i=0; i<listaVenta.size(); i++){
            if(listaVenta.get(i).getNumeroFactura() == numeroFactura){
                listaVenta.remove(i);
                encontrado = true;
            }
        }
        
        if(encontrado){
            escribir(listaVenta);
            return "Venta elminada exitosamente";
        }else{
            return "No existe venta a eliminar";
        }
        
    }
    
    public String anular(int numeroFactura){
        boolean anulada = false;
        String mensaje = "Factura número " + numeroFactura + ", no encontrada.";
        
        ArrayList<Venta> listaVentas = leer();
        
        for(Venta venta:listaVentas){
            if(venta.getNumeroFactura() == numeroFactura){
                
                if(venta.getAnulada() == true){
                    mensaje = "Factura número " +venta.getNumeroFactura() + ", ya ha sido anulada.";
                }else{
                    venta.setAnulada(true);
                    anulada = true;
                    mensaje =  "Factura número " + venta.getNumeroFactura() + ", anulada exitosamente.";
                    
                }
                break;
                
            }
            
        }
                
        if (anulada) {
            escribir(listaVentas);
        }
        
        return mensaje;
        
    }
    
    
    
    public ArrayList<Venta> buscar(String dato){
        ArrayList<Venta> listaVentasEncontradas = new ArrayList<>();
        ArrayList<Venta> listaVentasExistentes = leer();
        
        if(dato.isEmpty()){
            return listaVentasExistentes;
        }
        
        
        for(Venta venta: listaVentasExistentes){
            if(venta.getCliente().getNombre().contains(dato) || 
                venta.getCliente().getCedula().contains(dato)){
                listaVentasEncontradas.add(venta);
            }
        }
        return listaVentasEncontradas;
    }
}
