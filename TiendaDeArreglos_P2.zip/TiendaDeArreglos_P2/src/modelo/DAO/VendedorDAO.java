
package modelo.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import modelo.DTO.Vendedor;

public class VendedorDAO {

    private File archivo = new File("src/archivos/vendedores.obj");

    // LISTAR
    public ArrayList<Vendedor> listar() {

        ArrayList<Vendedor> lista = new ArrayList<>();

        try {
            if (archivo.exists()) {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo));
                lista = (ArrayList<Vendedor>) ois.readObject();
                ois.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    // GUARDAR
    public boolean guardar(Vendedor vendedor) {

        ArrayList<Vendedor> lista = listar();

        // VALIDAR DUPLICADO
        for (Vendedor v : lista) {
            if (v.getCodigoVendedor().equals(vendedor.getCodigoVendedor())
                    || v.getCedula().equals(vendedor.getCedula())) {
                return false;
            }
        }

        lista.add(vendedor);

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo));
            oos.writeObject(lista);
            oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    // ELIMINAR
    public void eliminar(String codigo) {

        ArrayList<Vendedor> lista = listar();

        for(int i=0;i<lista.size();i++){
            if(lista.get(i).getCodigoVendedor().equals(codigo)){
                lista.remove(i);
                break;
            }
        }

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo));
            oos.writeObject(lista);
            oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ArrayList<Vendedor> buscarPorNombre(String nombre) {

        ArrayList<Vendedor> resultado = new ArrayList<>();

        for (Vendedor v : listar()) {

            if (v.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                resultado.add(v);
            }
        }

        return resultado;
    }
       
}
