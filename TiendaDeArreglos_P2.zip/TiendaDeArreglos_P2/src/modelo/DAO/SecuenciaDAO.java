
package modelo.DAO;

import java.io.*;
import modelo.DTO.Secuencia;


public class SecuenciaDAO {
    String ruta = "src/archivos/secuencias.obj";
    
    
    
    public String escribir(Secuencia secuencia){
        String mensaje;
        try(FileOutputStream fos = new FileOutputStream(ruta);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
            ){
            oos.writeObject(secuencia);
            mensaje = "Secuencia guardado exitosamente";
            }catch(IOException io){
                System.out.println("Error al escribir la secuencia " + io.getMessage());
                mensaje = "No se guardó correctamente";
            }  
            return mensaje;
    }
    
    public Secuencia leer(){
        Secuencia secuencia = new Secuencia();
        
        //verificar si exis el arch
        File file = new File(ruta);
        if(!file.exists()){
            return secuencia;
        }
        
        try(FileInputStream fis = new FileInputStream(ruta);
            ObjectInputStream ois = new ObjectInputStream(fis);
        ){
            secuencia = (Secuencia)ois.readObject();
        }catch(IOException ioe){
            System.out.println("Error en leer secuencia " + ioe.getMessage());
        }catch(ClassNotFoundException cnf){
            System.out.println("Error en leer secuencia " + cnf.getMessage());
        }
        return secuencia;
        
    }
    
}
