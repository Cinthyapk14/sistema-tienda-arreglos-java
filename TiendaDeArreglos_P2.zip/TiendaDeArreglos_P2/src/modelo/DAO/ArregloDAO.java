package modelo.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import modelo.DTO.Arreglo;

public class ArregloDAO {

    String ruta = "src/archivos/arreglos.obj";//ruta relativa del archivo con datos de arreglos

    public String escribir(ArrayList<Arreglo> lista) {
        String mensaje;
        try (FileOutputStream fos = new FileOutputStream(ruta); ObjectOutputStream oos = new ObjectOutputStream(fos);//este obj nod permite hacer la serializacion
                ) {
            oos.writeObject(lista);//serializacion del objeto
            mensaje = "Arreglo guardado exitosamente";
        } catch (IOException ioe) {
            System.out.println("error al escribir Arreglo " + ioe.getMessage());
            mensaje = "No se guardo correctamente";
        }
        return mensaje;
    }

    public ArrayList<Arreglo> leer() {
        ArrayList<Arreglo> lista = new ArrayList();
        File file = new File(ruta);
        if (!file.exists()) {
            return lista;//retornar la lista vacia
        }
        try (FileInputStream fis = new FileInputStream(ruta); ObjectInputStream ois = new ObjectInputStream(fis);) {
            lista = (ArrayList<Arreglo>) ois.readObject(); //deserealizacion de los objetos
        } catch (IOException ioe) {
            System.out.println("Error en Arreglo " + ioe.getMessage());
        } catch (ClassNotFoundException cnf) {
            System.out.println("Error en Arreglo (class not found)" + cnf.getMessage());
        }
        return lista;
    }

    public String guardar(Arreglo arreglo) {
        ArrayList<Arreglo> lista = leer(); // leer los arreglos existentes
        //verificar si el arreglo ya existe
        for (Arreglo ar : lista) {
            if (ar.getIdArreglo().equals(arreglo.getIdArreglo())) {
                return "Ya existe ese Arreglo con codigo " + arreglo.getIdArreglo();
            }
        }
        lista.add(arreglo);
        String mensaje = escribir(lista);
        return mensaje;
    }

    public void eliminar(String id) {
        ArrayList<Arreglo> lista = leer();

        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getIdArreglo().equals(id)) {
                lista.remove(i);
                break;
            }
        }

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta));
            oos.writeObject(lista);
            oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Arreglo> buscar(String dato) {
        ArrayList<Arreglo> listaEncontrados = new ArrayList();
        ArrayList<Arreglo> listaExistentes = leer();
        if (dato.isEmpty()) { //si no hay dato de busqueda
            return listaExistentes; //retornar todos los Arreglos
        }
        //buscar
        for (Arreglo ar : listaExistentes) {
            if (ar.getNombreArreglo().contains(dato) || ar.getTipo().contains(dato) || ar.getListaMateriales().contains(dato)) {
                listaEncontrados.add(ar);
            }
        }
        return listaEncontrados;
    }

    public Arreglo buscarPorId(String id){
        ArrayList<Arreglo> listaExistente = leer();
        
        for(Arreglo arreglo: listaExistente){
            if(arreglo.getIdArreglo().equals(id)){
                return arreglo;
            }
        }
        return null;
    }
}
