package modelo.DAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import modelo.DTO.Cliente;

public class ClienteDAO {
    String ruta = "src/archivos/clientes.obj";//ruta relativa del archivo con datos de libros

    public String escribir(ArrayList<Cliente> lista) {
        String mensaje;
        try (FileOutputStream fos = new FileOutputStream(ruta);
                ObjectOutputStream oos = new ObjectOutputStream(fos);//este obj nod permite hacer la serializacion
                ) {
            oos.writeObject(lista);//serializacion del objeto
            mensaje = "Cliente gurdado exitosamente";
        } catch (IOException ioe) {
            System.out.println("error al escribir Cliente " + ioe.getMessage());
            mensaje = "No se guardo correctamente";
        }
        return mensaje;     
}   
    public ArrayList<Cliente> leer() {
        ArrayList<Cliente> lista = new ArrayList();
        File file = new File(ruta);
        if (!file.exists()) {
            return lista;//retornar la lista vacia
        }
        try (FileInputStream fis = new FileInputStream(ruta); ObjectInputStream ois = new ObjectInputStream(fis);) {
            lista = (ArrayList<Cliente>) ois.readObject(); //deserealizacion de los objetos
        } catch (IOException ioe) {
            System.out.println("Error en cliente " + ioe.getMessage());
        } catch (ClassNotFoundException cnf) {
            System.out.println("Error en cliente (class not found)" + cnf.getMessage());
        }
        return lista;
}
   
     public String guardar(Cliente cliente) {
      ArrayList<Cliente> lista = leer();

    for (Cliente cli : lista) {
        if (cli.getCedula().equals(cliente.getCedula())) {
            return "Ya existe un cliente con esa cédula";
        }
    }

     lista.add(cliente);
      escribir(lista);
       return "Cliente registrado correctamente";
}

 public String eliminar(String cedula) {
    ArrayList<Cliente> lista = leer();
    boolean encontrado = false;

    for (int i = 0; i < lista.size(); i++) {
        if (lista.get(i).getCedula().equals(cedula)) {
            lista.remove(i);
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        return "No existe el cliente a eliminar";
    } else {
        escribir(lista);
        return "Cliente eliminado exitosamente";
    }
}

    
    public ArrayList<Cliente> buscar(String dato) {
        ArrayList<Cliente> listaEncontrados = new ArrayList<>();
        ArrayList<Cliente> listaExistente = leer();

        // si no hay dato de búsqueda, devolver todos
        if (dato.isEmpty()) {
            return listaExistente;
        }

        // buscar por cédula, nombre o correo
        for (Cliente c : listaExistente) {
            if (c.getCedula().contains(dato)
                    || c.getNombre().toLowerCase().contains(dato.toLowerCase())
                    || c.getCedula().toLowerCase().contains(dato.toLowerCase())) {

                listaEncontrados.add(c);
            }
        }
        return listaEncontrados;
    }
}


    
        
    
