package modelo.DTO;

import java.io.Serializable;

public class Persona implements Serializable{
  // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
  
  
    private String nombre;
    private String cedula; 
    private int edad; 
 
    public Persona(){
    }
    public Persona(String nombre, String cedula, int edad){
    this.nombre = nombre;
    this.cedula = cedula; 
    this.edad = edad; 
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre; 
    }
    public String getCedula(){
        return cedula;
    }
    public void setCedula(String cedula){
        this.cedula = cedula;
    }
    public int getEdad(){
        return edad;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }

    @Override 
    public String toString(){
        return "Nombre:" + nombre +
               "\nCedula:" + cedula +
                "\nEdad:" + edad; 
    }
    public String obtenerResumen() {
        return "Persona: " + 
               "Nombre: " + nombre + 
               " Cedula: " + cedula + 
               " Edad: " + edad;
    }
}
