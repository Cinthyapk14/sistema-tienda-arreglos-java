package modelo.DTO;

import java.io.Serializable;
import java.util.*;

public class Arreglo implements Serializable {
    // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
    
    
    private String idArreglo;
    private String nombreArreglo;
    private String tipo;
    private String listaMateriales;
    private String nivelDificultad;
    private int tiempoElaboracion;
    private float precio;

    public Arreglo() {

    }

    public Arreglo(String idArreglo, String nombreArreglo, String tipo, String listaMateriales, String nivelDificultad, int tiempoElaboracion, float precio) {
        this.idArreglo = idArreglo;
        this.nombreArreglo = nombreArreglo;
        this.tipo = tipo;
        this.listaMateriales = listaMateriales;
        this.nivelDificultad = nivelDificultad;
        this.tiempoElaboracion = tiempoElaboracion;
        this.precio = precio;
    }

    public String getIdArreglo() {
        return idArreglo;
    }

    public String getNombreArreglo() {
        return nombreArreglo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getListaMateriales() {
        return listaMateriales;
    }

    public String getNivelDificultad() {
        return nivelDificultad;
    }

    public int getTiempoElaboracion() {
        return tiempoElaboracion;
    }

    public float getPrecio() {
        return precio;
    }

    public void setIdArreglo(String idArreglo) {
        this.idArreglo = idArreglo;
    }

    public void setNombreArreglo(String nombreArreglo) {
        this.nombreArreglo = nombreArreglo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setListaMateriales(String listaMateriales) {
        this.listaMateriales = listaMateriales;
    }

    public void setNivelDificultad(String nivelDificultad) {
        this.nivelDificultad = nivelDificultad;
    }

    public void setTiempoElaboracion(int tiempoElaboracion) {
        this.tiempoElaboracion = tiempoElaboracion;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Arreglo{" + "idArreglo = " + idArreglo
                + ", nombreArreglo = " + nombreArreglo + ", tipo = " + tipo
                + ", listaMateriales = " + listaMateriales + ", nivelDificultad = " + nivelDificultad
                + ", tiempoElaboracion = " + tiempoElaboracion + '}';
    }

}
