
package modelo.DTO;
import java.util.ArrayList;
import java.io.Serializable;
import java.time.LocalDateTime;
import modelo.DAO.SecuenciaDAO;

public class Venta implements Serializable{
    // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
    
    
    private int numeroFactura;
    private Vendedor vendedor;
    private Cliente cliente;
    private ArrayList<LineaVenta> lineasVentas;
    private float subTotal;
    private float IVA;
    private float totalPagar;
    private boolean anulada;
    private LocalDateTime registro;
    
    public Venta(){
        this.numeroFactura = obtenerNumeroFactura();
    }
    
    public Venta(Vendedor vendedor, Cliente cliente, ArrayList<LineaVenta> lineasVentas, float subTotal, float IVA, float totalPagar, LocalDateTime registro) {
        this.numeroFactura = obtenerNumeroFactura();
        this.vendedor = vendedor;
        this.cliente = cliente;
        this.lineasVentas = lineasVentas;
        this.subTotal = subTotal;
        this.IVA = IVA;
        this.totalPagar = totalPagar;
        this.anulada = false;
        this.registro = registro;
    }
    

    private int obtenerNumeroFactura(){
        SecuenciaDAO dao = new SecuenciaDAO();
        Secuencia secuencia = dao.leer();
        int numeroFactura = secuencia.obtenerSiguienteFactura();
        dao.escribir(secuencia);
        return numeroFactura;
    }
    
    
    //getters y setters
    public int getNumeroFactura(){
        return this.numeroFactura;
    }
    public void setNumeroFactura(int numeroFactura){
        this.numeroFactura = numeroFactura;
    }
    
    public Vendedor getVendedor(){
        return this.vendedor;
    }
    public void setVendedor(Vendedor vendedor){
        this.vendedor = vendedor;
    }
    
    public Cliente getCliente(){
        return this.cliente;
    }
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
    
    public ArrayList<LineaVenta> getLineasVentas(){
        return this.lineasVentas;
    }
    public void setLineasVentas(ArrayList<LineaVenta> lineasVentas){
        this.lineasVentas = lineasVentas;
    }
    

    
    public float getSubTotal(){
        return this.subTotal;
    }
    public void setSubTotal(float subTotal){
        this.subTotal = subTotal;
    }
    
    public float getIVA(){
        return this.IVA;
    }
    public void setIVA(float IVA){
        this.IVA = IVA;
    }
    
    public float getTotalPagar(){
        return this.totalPagar;
    }
    public void setTotalPagar(float totalPagar){
        this.totalPagar = totalPagar;
    }
    
    public boolean getAnulada(){
        return this.anulada;
    }
    public void setAnulada(boolean anulada){
        this.anulada = anulada;
    }
    
    public LocalDateTime getRegistro(){
        return this.registro;
    }
    public void setRegistro(LocalDateTime registro){
        this.registro = registro;
    }

    @Override
    public String toString() {
        return "Venta{" + "numeroFactura=" + numeroFactura + 
                ", vendedor=" + vendedor + ", cliente=" + cliente + 
                ", subTotal=" + subTotal + ", IVA=" + IVA + ", totalPagar=" + totalPagar + 
                ", registro=" + registro + '}';
    }
    
    
    
}
