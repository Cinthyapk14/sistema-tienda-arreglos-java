
package modelo.DTO;
import java.io.Serializable;

public class Secuencia implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private int factura;
    
    public Secuencia(){
        
    }
    
    
    public int getFactura(){
        return this.factura;
    }
    public void setFactura(int factura){
        this.factura = factura;
    }
    
    
    public int obtenerSiguienteFactura(){
        this.factura++;
        return this.factura;
    }

}
