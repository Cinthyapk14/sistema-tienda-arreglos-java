
package modelo.DTO;
  
import java.io.Serializable;

public class Vendedor extends Persona implements Serializable {
    // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
    
    private String codigoVendedor;
    private double sueldo;
    private String correo;
    private String area;

    public Vendedor() {
    }

    public Vendedor(String codigoVendedor, double sueldo,
            String nombre, String cedula, int edad,String correo,String area) {

        super(nombre, cedula, edad);
        this.codigoVendedor = codigoVendedor;
        this.sueldo = sueldo;
        this.correo = correo;
        this.area= area;
    }
    
    public String getCodigoVendedor() {
        return codigoVendedor;
    }

    public void setCodigoVendedor(String codigoVendedor) {
        this.codigoVendedor = codigoVendedor;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
    
    public String obtenerResumen(){
        return super.toString() +
                "\nCódigo Vendedor: " + codigoVendedor +
                "\nSueldo: " + sueldo+
                "\nArea:"+ correo ;
        
    }
    
    @Override
    public String toString() {
        return super.getNombre();
    }
    
}


