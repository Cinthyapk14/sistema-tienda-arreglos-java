package modelo.DTO;

import java.io.Serializable;

public class Cliente extends Persona implements Serializable {
    // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
    
    
    private String numTelefono;
    private String correo;

    public Cliente() {
        super(); 
    }

    public Cliente(String nombre, String cedula, int edad,
                   String numTelefono, String correo) {
        super(nombre, cedula, edad); 
        this.numTelefono = numTelefono;
        this.correo = correo;
    }

    // ✅ GETTERS Y SETTERS
    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    @Override 
    public String obtenerResumen() {
        return super.obtenerResumen() +
               "\nTeléfono: " + numTelefono +
               "\nCorreo: " + correo;
    }

    @Override
    public String toString() {
        return super.getNombre();
    }


    
    
}

