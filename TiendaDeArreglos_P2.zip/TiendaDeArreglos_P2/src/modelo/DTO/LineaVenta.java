
package modelo.DTO;
import java.io.Serializable;

public class LineaVenta implements Serializable{
    // Evita errores de deserialización si la estructura de la clase cambia
    private static final long serialVersionUID = 1L;
    
    
    private Arreglo arreglo;
    private int cantidad;
    
    //constructores
    public LineaVenta(){
        
    }
    public LineaVenta(Arreglo arreglo, int cantidad){
        this.cantidad = cantidad;
        this.arreglo = arreglo;
    }
    //getters y setters
    public Arreglo getArreglo(){
        return this.arreglo;
    }
    public void setArreglo(Arreglo arreglo){
        this.arreglo = arreglo;
    }
    public int getCantidad(){
        return this.cantidad;
    }
    public void setCantidad(int cantidad){
        this.cantidad = cantidad;
    }
    
    //calcular el total de la linea de venta
    public float obtenerTotalLineaVenta(){
        float total = this.cantidad * this.arreglo.getPrecio();
        return total;
    }
    
}
