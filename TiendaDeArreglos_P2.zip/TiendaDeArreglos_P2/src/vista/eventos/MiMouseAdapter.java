
package vista.eventos;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.DAO.ArregloDAO;
import modelo.DAO.ClienteDAO;
import modelo.DAO.VentaDAO;
import modelo.DTO.Cliente;
import modelo.DTO.Vendedor;
import modelo.DTO.Venta;
import modelo.DTO.LineaVenta;

import vista.*;

public class MiMouseAdapter extends MouseAdapter{
    private JFrame ventana;
    
    public MiMouseAdapter(JFrame ventana){
        this.ventana = ventana;
    }
    
    @Override
    public void mouseClicked(MouseEvent e){
        if(ventana instanceof VentanaRegistroVenta){
            
            VentanaRegistroVenta vrv = (VentanaRegistroVenta)ventana;
            
            if(e.getSource()== vrv.getBtnAnadir()){
                anadirLineaVentaTabla(vrv);
            }else if(e.getSource() == vrv.getBtnEliminar()){
                eliminarLineaVentaTabla(vrv);    
            }else if(e.getSource() == vrv.getBtnGuardar()){
                Guardar(vrv);
            }else if(e.getSource() == vrv.getBtnLimpiar()){
                limpiar(vrv);  
            }
            
        }
    }
    
    public boolean validar(VentanaRegistroVenta vrv){
        
        boolean incorrecto = false;
        
        if(vrv.getCmbVendedor().getSelectedIndex()== 0 ){
            JOptionPane.showMessageDialog(vrv, "Seleccione un vendedor");
            incorrecto = true;            
        }
        
        if(vrv.getLblNombreCliente().getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(vrv, "La cédula es obligatorio");
            incorrecto = true;
        }
        
        if(vrv.getLineasVentas().isEmpty()){
            JOptionPane.showMessageDialog(vrv, "No hay arreglo seleccionado");
            incorrecto = true;
        }
        
        return incorrecto;
        
    }
    
    public void Guardar(VentanaRegistroVenta vrv){
        
        if(!vrv.getBtnGuardar().isEnabled()){
            return;
        }
        
        boolean incorrecto = validar(vrv);
        
        if(incorrecto){
            return;
        }
        
        Vendedor vendedor = (Vendedor) vrv.getCmbVendedor().getSelectedItem();
        
        ClienteDAO dao = new ClienteDAO();
        Cliente cliente = dao.buscar(vrv.getTxtCedulaCliente().getText()).get(0);
        
        ArrayList<LineaVenta> lineasVentas = vrv.getLineasVentas();
        
        //Registro
        LocalDateTime ahora = LocalDateTime.now();
        
        float subTotal = vrv.getSubTotal();
        float IVA = vrv.getIVA();
        float totalPagar = vrv.getTotalPagar();
        //Constructor        
        Venta venta = new Venta(vendedor, cliente, lineasVentas, subTotal, IVA, totalPagar, ahora);
        
        vrv.getLblNumeroFactura().setText(Integer.toString(venta.getNumeroFactura()));
        
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        vrv.getLblRegistro().setText(ahora.format(formato));
        
        
        //Crear obje
        //Venta venta = new Venta();
        VentaDAO ventaDao = new VentaDAO();
        String mensaje = ventaDao.guardar(venta);
        vrv.getBtnGuardar().setEnabled(false);
        
        JOptionPane.showMessageDialog(vrv, mensaje);
        
    }

    public void limpiar (VentanaRegistroVenta vrv){
        vrv.limpiarComponentes();
        
        vrv.getBtnGuardar().setEnabled(true);
        //vrv.getTxtCedulaCliente().setEnabled(true);
    }
    public void anadirLineaVentaTabla(VentanaRegistroVenta vrv){

        VentanaBusquedaLineaVenta ventana = new VentanaBusquedaLineaVenta(vrv);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        
    }
    
    public void eliminarLineaVentaTabla(VentanaRegistroVenta vrv){
        
        if(vrv.getLineasVentas().isEmpty()){
            return;
        }
        
        int numFila = vrv.getTableDetalleVenta().getSelectedRow();
        
        if(numFila == -1){
            JOptionPane.showMessageDialog(vrv, "Debe seleccionar una linea de venta");
            return;
        }
        
        int op= JOptionPane.showConfirmDialog(vrv, "¿Está seguro?","Confirmación",
                JOptionPane.YES_NO_OPTION);
        
        if(op == JOptionPane.YES_OPTION){
        
            String idArreglo = vrv.getTableDetalleVenta().getValueAt(numFila, 0).toString();
            
            DefaultTableModel modelo = (DefaultTableModel)vrv.getTableDetalleVenta().getModel();
            modelo.removeRow(numFila);
            
            ArrayList<LineaVenta> lineaVenta = vrv.getLineasVentas();
            for(int i =0; i<lineaVenta.size(); i++){
                if(lineaVenta.get(i).getArreglo().getIdArreglo().equals(idArreglo)){
                    lineaVenta.remove(i);
                    break;
                }
            }
            
            vrv.calcularTotalPagar();
            
        }
    }
    
    

    

    
    
    
}
