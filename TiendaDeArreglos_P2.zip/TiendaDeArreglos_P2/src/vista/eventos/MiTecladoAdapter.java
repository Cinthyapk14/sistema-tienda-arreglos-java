
package vista.eventos;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import modelo.DAO.ClienteDAO;
import modelo.DTO.Cliente;
import vista.*;

public class MiTecladoAdapter extends KeyAdapter{
    private JFrame ventana;
    
    public MiTecladoAdapter(JFrame ventana){
        this.ventana = ventana;
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        
        if(ventana instanceof VentanaRegistroVenta){
            
            VentanaRegistroVenta vrv = (VentanaRegistroVenta)ventana;
            if(e.getSource() == vrv.getTxtCedulaCliente()){                
                
                tipearNumeroCedula(e, vrv.getTxtCedulaCliente());          
                
                if (vrv.getTxtCedulaCliente().getText().length() != 10) {
                    vrv.getLblNombreCliente().setText("");
                }
                
            }
            
        }else if(ventana instanceof VentanaBusquedaVenta){
            VentanaBusquedaVenta vbv = (VentanaBusquedaVenta)ventana;
        }
        
    }
    
    
    public void tipearNumeroCedula(KeyEvent e, JTextField txt){
        char c = e.getKeyChar();
        if(!Character.isDigit(c)){
            e.consume();
        }
        if(txt.getText().length()>=10){
            e.consume();
        }
    }
    
    public void tipearLetra(KeyEvent e, JTextField txt){
        char c  = e.getKeyChar();
        if(!Character.isLetter(c) && c!=' ' && c!='-'){
            e.consume();
        }
    }
    
    
}
