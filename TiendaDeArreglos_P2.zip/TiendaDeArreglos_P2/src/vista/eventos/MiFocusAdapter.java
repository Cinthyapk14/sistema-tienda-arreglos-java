
package vista.eventos;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.ArrayList;
import javax.swing.*;
import modelo.DAO.ClienteDAO;
import modelo.DTO.Cliente;
import vista.VentanaRegistroVenta;


public class MiFocusAdapter extends FocusAdapter{
    private JFrame ventana;
    
    public MiFocusAdapter(JFrame ventana){
        this.ventana = ventana;
    }

    @Override
    public void focusLost(FocusEvent e) {
        if(ventana instanceof VentanaRegistroVenta){
            VentanaRegistroVenta vrv = (VentanaRegistroVenta)ventana;
            if(e.getSource() == vrv.getTxtCedulaCliente()){
                agregarNombreCliente(vrv, e, vrv.getTxtCedulaCliente(), vrv.getLblNombreCliente());
            }
        }
        
    }
    
    public void agregarNombreCliente(VentanaRegistroVenta ven, FocusEvent e, JTextField txt ,JLabel lbl){
        String cedula = txt.getText().trim();
        if (cedula.length() == 10) {
            ClienteDAO dao = new ClienteDAO();
            ArrayList<Cliente> listaClientes = dao.buscar(cedula);
            if(!listaClientes.isEmpty()){
                lbl.setText(listaClientes.get(0).getNombre());
                //ven.getTxtCedulaCliente().setEnabled(false);
                return;
            }
        }        
        if (cedula.length() != 0)
        {
            lbl.setText("");
            JOptionPane.showMessageDialog(ventana, "Cliente no encontrado");
        }        
    }
    
    
    
}
