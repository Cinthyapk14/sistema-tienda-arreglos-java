
package vista.eventos;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.*;
import vista.*;

public class MiComponenteAdapter extends ComponentAdapter{
    private JFrame ventana;
    
    public MiComponenteAdapter(JFrame ventana){
        this.ventana = ventana;
    }
    
    @Override
    public void componentMoved(ComponentEvent e) {
        
        if(ventana instanceof VentanaPrincipal){
            VentanaPrincipal ventanaPrincipal = (VentanaPrincipal)ventana;
            
            if(e.getSource() == ventanaPrincipal.getVentana()){
                colocarVentanaPosicion(ventanaPrincipal, e);
            }
            
        }else if(ventana instanceof VentanaRegistroVenta){
            VentanaRegistroVenta ventanaRegistroVenta = (VentanaRegistroVenta) ventana;
            
            if(e.getSource() == ventanaRegistroVenta.getVentana()){
                colocarVentanaPosicion(ventanaRegistroVenta, e);
            }
            
        }else if(ventana instanceof VentanaBusquedaVenta){
            VentanaBusquedaVenta ventanaBusquedaVenta = (VentanaBusquedaVenta)ventana;
            
            if(e.getSource() == ventanaBusquedaVenta.getVentana()){
                colocarVentanaPosicion(ventanaBusquedaVenta, e);
            }
            
        }else if(ventana instanceof VentanaBusquedaLineaVenta){
            VentanaBusquedaLineaVenta ventanaBusquedaLineaVenta = (VentanaBusquedaLineaVenta)ventana;
            
            if(e.getSource() == ventanaBusquedaLineaVenta.getVentana()){
                colocarVentanaPosicion(ventanaBusquedaLineaVenta, e);
            }
        }
        
    }
    
    public void colocarVentanaPosicion(JFrame ventana1, ComponentEvent e){
        
        if(ventana1 instanceof VentanaPrincipal){
            VentanaPrincipal ventana = (VentanaPrincipal)ventana1;
            ventana.getVentana().setLocationRelativeTo(null);
            
        }else if(ventana1 instanceof VentanaRegistroVenta){
            VentanaRegistroVenta ventana = (VentanaRegistroVenta)ventana1;
            ventana.getVentana().setLocationRelativeTo(null);//000
            
        }else if(ventana1 instanceof VentanaBusquedaVenta){
            VentanaBusquedaVenta ventana = (VentanaBusquedaVenta)ventana1;
            ventana.getVentana().setLocationRelativeTo(null);
            
        }else if(ventana1 instanceof VentanaBusquedaLineaVenta){
            VentanaBusquedaLineaVenta ventana = (VentanaBusquedaLineaVenta)ventana1;
            ventana.getVentana().setLocationRelativeTo(null);
        }
    }
    
    
    
}
