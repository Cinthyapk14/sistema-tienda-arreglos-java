
package vista.eventos;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class MiVentanaAdapter extends WindowAdapter{
    private JFrame ventana;
    
    public MiVentanaAdapter(JFrame ventana){
        this.ventana = ventana;
    }

    @Override
    public void windowClosing(WindowEvent e) {
        int opcion = JOptionPane.showConfirmDialog(ventana, "¿Está seguro de cerrar?",
                "Confirmar", JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        
        if(opcion == JOptionPane.YES_OPTION){
            if(ventana.getTitle().equals("Ventana Principal")){
                System.exit(0);
            }else{
                ventana.dispose();
            }
        }
    }

    public void WindowClosing(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
